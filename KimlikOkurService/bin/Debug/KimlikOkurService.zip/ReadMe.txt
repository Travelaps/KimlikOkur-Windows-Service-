1-)KimlikOkurService windows servisini yüklemek için install.bat dosyasını çalıştırınız.
2-)install.bat dosyası windows servisi yükledikten sonra "Yükleme tamamlandı" mesajını verecektir.
3-)Windows hizmetler menüsünden "KimlikOkurService" adlı windows servisini bulunuz ve başlatınız. Servis ; bilgisayarı bir sonraki başlatmada otomatik olarak başlayacaktır.
4-)Windows servis başlatıldıktan sonra 127.0.0.1 local ip üzerinden 8019 nolu port üzerinden sunucuyu başlatacaktır.
5-)Kurulumunuz artık tamamlanmış olacaktır.

Servisi Kaldırmak İçin:
KimlikOkurService windows servisini kaldırmak için uninstall.bat dosyasını çalıştırmanız yeterlidir.

Servis Logs:

1-) Servise ait log kayıtlarına ulaşmak için windows olay görüntüleyici açınız.
2-) Açılan pencerede Uygulama Ve Hizmet Günlükleri bölümünden "KimlikOkurLog" dosyasından servisin log bilgilerine ulaşabilirsiniz.